package exercise1;

public class PlayerGame {
    private long id;
    private long playerId;
    private long gameId;

    public PlayerGame(long id, long playerId, long gameId) {
        this.id = id;
        this.playerId = playerId;
        this.gameId = gameId;
    }

    // getters + toString()
}
