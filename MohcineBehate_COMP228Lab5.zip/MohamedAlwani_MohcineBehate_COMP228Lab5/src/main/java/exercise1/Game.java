package exercise1;

public class Game {
    private long gameId;
    private String gameTitle;

    public Game(long gameId, String gameTitle) {
        this.gameId = gameId;
        this.gameTitle = gameTitle;
    }

    // getters + toString()
}
